/**
 * WTR-Lab Old UI — background.js  v1.2.0  (MV3 service worker)
 * ─────────────────────────────────────────────────────────────
 *
 * INJECTION LIFECYCLE
 * ───────────────────
 * 1. tabs.onUpdated (status='loading', frameId=0, real navigation only)
 *    → clear stale dedup entry → injectCSS (batched, single IPC call)
 * 2. tabs.onUpdated (status='complete')
 *    → notify content.js to apply theme classes
 * 3. webNavigation.onHistoryStateUpdated (SPA pushState)
 *    → CSS already present, just re-notify content.js
 * 4. runtime.onStartup / onInstalled
 *    → inject into already-open tabs
 *
 * DUPLICATE PREVENTION
 * ─────────────────────
 * Fast path : injectedTabs Set  (in-memory, O(1))
 * Fallback  : DOM marker check via executeScript (survives SW restarts)
 * Marker is set ONLY after successful injection, removed on disable.
 *
 * STORAGE CACHE
 * ─────────────
 * enabledCache avoids repeated storage.sync.get calls.
 * Initialized once at SW startup, kept in sync via storage.onChanged.
 * All hot paths read from cache; only cold start falls back to storage.
 *
 * KNOWN MV3 LIMITATIONS
 * ──────────────────────
 * • Service worker can be suspended; injectedTabs Set is lost.
 *   DOM marker fallback handles this case.
 * • insertCSS/removeCSS are per-document; SPA navigation preserves CSS.
 * • executeScript for marker check adds ~1 IPC round-trip on SW restart.
 */

'use strict';

/* ─── Config ─────────────────────────────────────────────────────────────── */
const DEBUG     = false;
const CSS_FILES = ['bs.css', 'wtr.css', 'widgets.css'];
const MARKER    = 'data-wtr-injected';
const WTR_URL   = 'https://wtr-lab.com/*';
const WTR_HOST  = 'wtr-lab.com';

const log  = (...a) => { if (DEBUG) console.log('[WTR-BG]', ...a); };
const warn = (...a) => { if (DEBUG) console.warn('[WTR-BG]', ...a); };

/* ─── In-memory state ────────────────────────────────────────────────────── */
// enabledCache: undefined = not yet loaded, true/false = known state
let enabledCache = undefined;

// Per-tab injection dedup (fast path; may desync after SW restart)
const injectedTabs = new Set();

/* ═══════════════════════════════════════════════════════════════════════════
   STORAGE CACHE
   Initialize once; keep in sync via onChanged.
   All hot paths use getEnabled() which reads cache first.
   ═══════════════════════════════════════════════════════════════════════════ */
async function getEnabled() {
  if (enabledCache !== undefined) return enabledCache;
  const { enabled } = await chrome.storage.sync.get({ enabled: true });
  enabledCache = enabled;
  log('cache miss — loaded from storage:', enabledCache);
  return enabledCache;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && 'enabled' in changes) {
    enabledCache = changes.enabled.newValue;
    log('cache updated via onChanged:', enabledCache);
  }
});

/* ═══════════════════════════════════════════════════════════════════════════
   DOM MARKER CHECK  (fallback for SW restart desyncs)
   Only called when injectedTabs Set misses — avoids IPC on hot path.
   ═══════════════════════════════════════════════════════════════════════════ */
async function isAlreadyInjected(tabId) {
  if (injectedTabs.has(tabId)) return true;
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      func: (attr) => document.documentElement.hasAttribute(attr),
      args: [MARKER],
    });
    const found = res?.result === true;
    if (found) injectedTabs.add(tabId); // re-sync Set from DOM truth
    return found;
  } catch (_) {
    return false; // tab not ready or no access — treat as not injected
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   CSS INJECT / REMOVE  (batched — single IPC call each)
   ═══════════════════════════════════════════════════════════════════════════ */
async function injectCSS(tabId) {
  if (await isAlreadyInjected(tabId)) {
    log(`tab ${tabId} already injected — skipping`);
    return false;
  }

  try {
    // Single batched call — all files in one IPC round-trip
    await chrome.scripting.insertCSS({ target: { tabId, allFrames: false }, files: CSS_FILES });
    injectedTabs.add(tabId);
    log(`CSS injected → tab ${tabId}`);
    return true;
  } catch (e) {
    warn(`inject failed tab ${tabId}:`, e.message);
    // Do NOT add to injectedTabs — failed injection must not leave stale marker
    return false;
  }
}

async function removeCSS(tabId) {
  try {
    await chrome.scripting.removeCSS({ target: { tabId, allFrames: false }, files: CSS_FILES });
  } catch (_) {
    // Tab may already be gone or CSS already removed — not an error
  }
  injectedTabs.delete(tabId);
  log(`CSS removed ← tab ${tabId}`);
}

/* ─── Notify content script ─────────────────────────────────────────────── */
function notify(tabId, type) {
  chrome.tabs.sendMessage(tabId, { type }).catch(() => {});
}

/* ═══════════════════════════════════════════════════════════════════════════
   INSTALL / UPDATE
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    await chrome.storage.sync.set({ enabled: true });
    enabledCache = true;
    log('installed — default enabled=true');
  }
  // On update: re-inject into open tabs to pick up new CSS files
  if (reason === 'update') {
    enabledCache = await getEnabled();
    if (!enabledCache) return;
    const tabs = await chrome.tabs.query({ url: WTR_URL });
    for (const tab of tabs) {
      injectedTabs.delete(tab.id);
      await injectCSS(tab.id);
      notify(tab.id, 'WTR_ENABLE');
    }
    log('update — re-injected into', tabs.length, 'tabs');
  }
});

/* ═══════════════════════════════════════════════════════════════════════════
   TAB LIFECYCLE
   ─────────────
   Filter criteria (hardened):
   • status must be 'loading' or 'complete'
   • tab.url must include wtr-lab.com
   • info.url must be present on 'loading' (real navigation, not favicon/title)
   • frameId check via webNavigation is handled separately
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  // Only handle real navigations — skip favicon, title, audible, etc.
  if (info.status !== 'loading' && info.status !== 'complete') return;

  // Validate URL — tab.url may be empty for prerender/discarded tabs
  const url = tab.url || info.url || '';
  if (!url.includes(WTR_HOST)) return;

  // Skip prerendered / discarded tabs
  if (tab.discarded) return;

  const on = await getEnabled();
  if (!on) return;

  if (info.status === 'loading') {
    // New navigation — clear stale dedup so we re-inject cleanly
    // Only clear if info.url is present (real navigation, not sub-resource load)
    if (info.url) {
      injectedTabs.delete(tabId);
      log(`tab ${tabId} navigating to ${info.url} — cleared dedup`);
    }
    await injectCSS(tabId);
  }

  if (info.status === 'complete') {
    // DOM is ready — tell content.js to apply theme classes
    notify(tabId, 'WTR_ENABLE');
  }
});

/* ─── Tab closed ─────────────────────────────────────────────────────────── */
chrome.tabs.onRemoved.addListener((tabId) => {
  injectedTabs.delete(tabId);
});

/* ═══════════════════════════════════════════════════════════════════════════
   SPA NAVIGATION  (Next.js pushState / replaceState)
   ─────────────────────────────────────────────────
   insertCSS survives SPA navigation (CSS is per-document, not per-URL).
   We only need to re-notify content.js to re-apply theme classes after
   React re-renders the page tree.
   frameId: 0 ensures we only handle main frame navigations.
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return; // main frame only
  if (!details.url?.includes(WTR_HOST)) return;

  const on = await getEnabled();
  if (!on) return;

  log('SPA nav →', details.url);
  notify(details.tabId, 'WTR_ENABLE');
}, { url: [{ hostContains: WTR_HOST }] });

/* ═══════════════════════════════════════════════════════════════════════════
   POPUP TOGGLE
   ─────────────
   Instantly propagates to all open WTR-Lab tabs including:
   • active tabs
   • inactive/background tabs
   • duplicated tabs
   • tabs restored from session
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'WTR_TOGGLE') return false;

  (async () => {
    const { enabled } = msg;

    // Update storage + cache atomically
    await chrome.storage.sync.set({ enabled });
    enabledCache = enabled;
    log('toggle →', enabled);

    const tabs = await chrome.tabs.query({ url: WTR_URL });
    for (const tab of tabs) {
      if (tab.discarded) continue; // skip discarded tabs
      if (enabled) {
        injectedTabs.delete(tab.id); // force fresh inject
        await injectCSS(tab.id);
        notify(tab.id, 'WTR_ENABLE');
      } else {
        await removeCSS(tab.id);
        notify(tab.id, 'WTR_DISABLE');
      }
    }

    sendResponse({ ok: true });
  })();

  return true; // keep message channel open for async response
});

/* ═══════════════════════════════════════════════════════════════════════════
   BROWSER STARTUP  (handles already-open tabs after browser restart)
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.runtime.onStartup.addListener(async () => {
  enabledCache = await getEnabled(); // warm cache on startup
  if (!enabledCache) return;

  const tabs = await chrome.tabs.query({ url: WTR_URL });
  for (const tab of tabs) {
    if (tab.discarded) continue;
    injectedTabs.delete(tab.id); // SW restarted — Set is stale, DOM marker is truth
    await injectCSS(tab.id);
    notify(tab.id, 'WTR_ENABLE');
  }
  log('startup — processed', tabs.length, 'existing tabs');
});
