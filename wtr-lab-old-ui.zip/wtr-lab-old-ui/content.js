/**
 * WTR-Lab Old UI — content.js  v1.2.0
 * run_at: document_start
 * ─────────────────────────────────────────────────────────────────────────
 *
 * THEME BOOTSTRAP SEQUENCE
 * ─────────────────────────
 * 1. document_start fires (before HTML parsed, before first paint)
 * 2. storage.sync.get reads enabled state (async, ~5ms)
 * 3. If enabled: saveOriginalState() → applyTheme() → set MARKER_ATTR
 * 4. DOMContentLoaded: start hydration guard + route watcher + OS listener
 *
 * THEME DETECTION  (mirrors source en.html verbatim)
 * ───────────────────────────────────────────────────
 * Priority: localStorage.config.darkMode → OS matchMedia preference
 * All reads are wrapped in try/catch — cannot throw at document_start.
 *
 * HYDRATION GUARD LOGIC
 * ──────────────────────
 * Watches ONLY class + data-bs-theme + data-color-mode attributes on
 * <html> and <body>. Re-entrancy guard (correcting flag) prevents loops.
 * Disconnected on disable, reconnected on re-enable — singleton safe.
 *
 * SPA ROUTING STRATEGY
 * ─────────────────────
 * Primary  : MutationObserver on <title> (Next.js always updates on nav)
 * Secondary: popstate event (back/forward)
 * background.js also handles webNavigation.onHistoryStateUpdated for
 * CSS re-injection if needed (CSS survives SPA nav, only theme re-apply needed).
 *
 * MARKER SYNCHRONIZATION
 * ───────────────────────
 * data-wtr-injected is set on <html> ONLY after successful enable().
 * Removed on disable(). background.js reads this via executeScript as
 * fallback dedup check after service-worker restarts.
 *
 * SINGLETON SAFETY
 * ─────────────────
 * All observers/listeners stored in module-level variables.
 * Each start* function checks its variable before creating a new instance.
 * Repeated enable/disable cycles never create duplicate handlers.
 *
 * KNOWN LIMITATIONS (cannot fix with CSS alone)
 * ──────────────────────────────────────────────
 * • If modern WTR-Lab renames root containers (.layout-body, .serie-item,
 *   etc.) legacy CSS selectors will not match — requires selector remapping.
 * • Dynamic components injected by React after hydration (modals, toasts)
 *   may use new class names not present in legacy CSS.
 * • Inline styles set by React (style="...") override CSS rules regardless
 *   of specificity — would require DOM shims to fix.
 * • CSS Modules / hashed selectors in new WTR-Lab cannot be targeted by
 *   legacy rules — would require synthetic wrapper nodes.
 */

'use strict';

/* ═══════════════════════════════════════════════════════════════════════════
   CONFIG & DEBUG
   ═══════════════════════════════════════════════════════════════════════════ */
const DEBUG = false;

const log  = (...a) => { if (DEBUG) console.log('[WTR]',  ...a); };
const warn = (...a) => { if (DEBUG) console.warn('[WTR]',  ...a); };

/* ═══════════════════════════════════════════════════════════════════════════
   CONSTANTS
   ═══════════════════════════════════════════════════════════════════════════ */
const MARKER_ATTR = 'data-wtr-injected'; // set on <html> when extension is active
const ORIGIN_ATTR = 'data-wtr-origin';   // stores original site state for restore

// Legacy DOM structures we expect to exist — used for compatibility diagnostics
const EXPECTED_SELECTORS = [
  '.layout-body',
  '.serie-item',
  '.navbar',
  '.continue-reading',
  '.bottom-reader-nav',
  '.chapter-body',
];

/* ═══════════════════════════════════════════════════════════════════════════
   MODULE STATE  (singleton guards)
   ═══════════════════════════════════════════════════════════════════════════ */
let enabled          = false;
let hydrationObs     = null;   // MutationObserver — <html>/<body> attrs
let routeObs         = null;   // MutationObserver — <title> childList
let popstateHandler  = null;   // popstate listener reference
let osThemeHandler   = null;   // matchMedia change listener reference
let lastUrl          = location.href;

/* ═══════════════════════════════════════════════════════════════════════════
   THEME DETECTION
   Verbatim logic from source en.html — wrapped for safety at document_start.
   ═══════════════════════════════════════════════════════════════════════════ */
function isDarkMode() {
  // 1. Site preference from localStorage
  try {
    const raw = localStorage.getItem('config');
    if (raw) {
      const cfg = JSON.parse(raw);
      if (typeof cfg.darkMode === 'boolean') {
        log('theme source: localStorage →', cfg.darkMode ? 'dark' : 'light');
        return cfg.darkMode;
      }
    }
  } catch (e) {
    warn('localStorage read failed:', e.message);
  }

  // 2. OS preference fallback — guaranteed to not throw
  try {
    const matches = window.matchMedia('(prefers-color-scheme: dark)').matches;
    log('theme source: OS preference →', matches ? 'dark' : 'light');
    return matches;
  } catch (e) {
    warn('matchMedia failed:', e.message);
    return false; // absolute fallback: light mode
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   ORIGINAL STATE PRESERVATION
   Saved once before first override. Restored exactly on disable.
   ═══════════════════════════════════════════════════════════════════════════ */
function saveOriginalState() {
  if (document.documentElement.hasAttribute(ORIGIN_ATTR)) return; // already saved

  const state = {
    bsTheme:   document.documentElement.getAttribute('data-bs-theme')   ?? '',
    colorMode: document.documentElement.getAttribute('data-color-mode') ?? '',
    htmlClass: document.documentElement.className,
    bodyClass: document.body?.className ?? '',
  };

  try {
    document.documentElement.setAttribute(ORIGIN_ATTR, JSON.stringify(state));
    log('original state saved:', state);
  } catch (e) {
    warn('failed to save original state:', e.message);
  }
}

function restoreOriginalState() {
  const raw = document.documentElement.getAttribute(ORIGIN_ATTR);
  if (!raw) return;

  try {
    const s = JSON.parse(raw);

    if (s.bsTheme)   document.documentElement.setAttribute('data-bs-theme',   s.bsTheme);
    else             document.documentElement.removeAttribute('data-bs-theme');

    if (s.colorMode) document.documentElement.setAttribute('data-color-mode', s.colorMode);
    else             document.documentElement.removeAttribute('data-color-mode');

    document.documentElement.className = s.htmlClass;
    if (document.body) document.body.className = s.bodyClass;

    document.documentElement.removeAttribute(ORIGIN_ATTR);
    log('original state restored');
  } catch (e) {
    warn('failed to restore original state:', e.message);
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   THEME APPLICATION
   ═══════════════════════════════════════════════════════════════════════════ */
function applyTheme() {
  try {
    const dark = isDarkMode();
    const on   = dark ? 'dark'  : 'light';
    const off  = dark ? 'light' : 'dark';

    document.documentElement.setAttribute('data-bs-theme',   on);
    document.documentElement.setAttribute('data-color-mode', on);
    document.documentElement.classList.add(on  + '-mode');
    document.documentElement.classList.remove(off + '-mode');

    if (document.body) {
      document.body.classList.add(on  + '-mode');
      document.body.classList.remove(off + '-mode');
    }

    log('theme applied:', on);
  } catch (e) {
    warn('applyTheme failed:', e.message);
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   HYDRATION GUARD
   ─────────────────
   React may strip our theme classes/attrs during hydration or re-renders.
   We watch ONLY the specific attributes we set — minimal overhead.
   Re-entrancy guard prevents the observer from triggering itself.
   ═══════════════════════════════════════════════════════════════════════════ */
function startHydrationGuard() {
  if (hydrationObs) return; // singleton — already running

  let correcting = false;

  const check = () => {
    if (!enabled || correcting) return;

    const dark     = isDarkMode();
    const expected = dark ? 'dark-mode' : 'light-mode';
    const wrongAttr = document.documentElement.getAttribute('data-bs-theme') !== (dark ? 'dark' : 'light');
    const htmlMiss  = !document.documentElement.classList.contains(expected);
    const bodyMiss  = document.body && !document.body.classList.contains(expected);

    if (wrongAttr || htmlMiss || bodyMiss) {
      log('hydration correction triggered');
      correcting = true;
      applyTheme();
      correcting = false;
    }
  };

  hydrationObs = new MutationObserver(check);

  // Watch <html> attributes
  hydrationObs.observe(document.documentElement, {
    attributes:      true,
    attributeFilter: ['class', 'data-bs-theme', 'data-color-mode'],
    subtree:         false,
    childList:       false,
  });

  // Watch <body> attributes — attach now or after DOMContentLoaded
  const observeBody = () => {
    if (document.body && hydrationObs) {
      hydrationObs.observe(document.body, {
        attributes:      true,
        attributeFilter: ['class'],
        subtree:         false,
        childList:       false,
      });
      log('hydration guard observing <body>');
    }
  };

  if (document.body) {
    observeBody();
  } else {
    document.addEventListener('DOMContentLoaded', observeBody, { once: true });
  }

  log('hydration guard started');
}

function stopHydrationGuard() {
  if (!hydrationObs) return;
  hydrationObs.disconnect();
  hydrationObs = null;
  log('hydration guard stopped');
}

/* ═══════════════════════════════════════════════════════════════════════════
   SPA ROUTE WATCHER
   ─────────────────
   Next.js always updates <title> on client-side navigation.
   We watch childList on <title> and compare location.href.
   popstate handles back/forward navigation.
   ═══════════════════════════════════════════════════════════════════════════ */
function onRouteChange() {
  if (!enabled) return;
  log('SPA route change →', location.href);
  applyTheme();
  if (DEBUG) runCompatibilityCheck();
}

function startRouteWatcher() {
  if (routeObs) return; // singleton

  const titleEl = document.querySelector('title');
  if (titleEl) {
    routeObs = new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        onRouteChange();
      }
    });
    routeObs.observe(titleEl, { childList: true });
    log('route watcher started on <title>');
  } else {
    warn('route watcher: <title> not found — SPA nav may not be detected');
  }

  // popstate: back/forward buttons
  popstateHandler = onRouteChange;
  window.addEventListener('popstate', popstateHandler);
}

function stopRouteWatcher() {
  if (routeObs) {
    routeObs.disconnect();
    routeObs = null;
  }
  if (popstateHandler) {
    window.removeEventListener('popstate', popstateHandler);
    popstateHandler = null;
  }
  log('route watcher stopped');
}

/* ═══════════════════════════════════════════════════════════════════════════
   OS THEME LISTENER
   Only fires when OS dark/light preference changes AND no site pref is saved.
   ═══════════════════════════════════════════════════════════════════════════ */
function startOsThemeListener() {
  if (osThemeHandler) return; // singleton

  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  osThemeHandler = () => {
    if (!enabled) return;
    // Only act if site has no saved preference
    try {
      const cfg = JSON.parse(localStorage.getItem('config') || '{}');
      if (typeof cfg.darkMode === 'boolean') return; // site pref takes priority
    } catch (_) {}
    log('OS theme changed — re-applying');
    applyTheme();
  };
  mq.addEventListener('change', osThemeHandler);
  log('OS theme listener started');
}

function stopOsThemeListener() {
  if (!osThemeHandler) return;
  window.matchMedia('(prefers-color-scheme: dark)')
    .removeEventListener('change', osThemeHandler);
  osThemeHandler = null;
  log('OS theme listener stopped');
}

/* ═══════════════════════════════════════════════════════════════════════════
   COMPATIBILITY DIAGNOSTICS  (DEBUG only)
   Checks for expected legacy DOM structures.
   Does NOT attempt to fix anything — only logs warnings.
   ═══════════════════════════════════════════════════════════════════════════ */
function runCompatibilityCheck() {
  if (!DEBUG) return;

  log('── compatibility check ──');

  // Check expected selectors
  for (const sel of EXPECTED_SELECTORS) {
    if (!document.querySelector(sel)) {
      warn(`missing expected element: "${sel}" — legacy CSS may not apply here`);
    }
  }

  // Check for inline styles that may override legacy CSS
  const inlineStyled = document.querySelectorAll('[style]');
  if (inlineStyled.length > 20) {
    warn(`${inlineStyled.length} elements have inline styles — some may override legacy CSS`);
  }

  // Check for runtime <style> tags injected by the new site
  const runtimeStyles = document.querySelectorAll('style[data-emotion], style[data-styled]');
  if (runtimeStyles.length > 0) {
    warn(`${runtimeStyles.length} runtime CSS-in-JS style tags detected — may conflict with legacy CSS`);
  }

  // Check theme classes are applied
  const dark = isDarkMode();
  const expected = dark ? 'dark-mode' : 'light-mode';
  if (!document.body?.classList.contains(expected)) {
    warn(`body missing expected class "${expected}"`);
  }
  if (document.documentElement.getAttribute('data-bs-theme') !== (dark ? 'dark' : 'light')) {
    warn('data-bs-theme attribute mismatch');
  }

  log('── compatibility check done ──');
}

/* ═══════════════════════════════════════════════════════════════════════════
   ENABLE / DISABLE LIFECYCLE
   ─────────────────────────────
   enable() is idempotent — safe to call multiple times.
   disable() is fail-safe — each step is independent, errors don't cascade.
   ═══════════════════════════════════════════════════════════════════════════ */
function enable() {
  if (enabled) {
    // Already running — just re-apply theme (handles WTR_ENABLE after SPA nav)
    applyTheme();
    log('re-enable: theme re-applied');
    return;
  }

  enabled = true;

  // Save original state before any modifications
  saveOriginalState();

  // Apply theme immediately (document_start — before first paint)
  applyTheme();

  // Set DOM marker AFTER successful theme application
  try {
    document.documentElement.setAttribute(MARKER_ATTR, '1');
  } catch (e) {
    warn('failed to set marker:', e.message);
  }

  // Start watchers — defer until DOM is ready if needed
  const startWatchers = () => {
    startHydrationGuard();
    startRouteWatcher();
    startOsThemeListener();
    if (DEBUG) runCompatibilityCheck();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startWatchers, { once: true });
  } else {
    startWatchers();
  }

  log('enabled');
}

function disable() {
  // Set flag first so all guards stop reacting
  enabled = false;

  // Stop all observers/listeners — each is independent
  try { stopHydrationGuard();  } catch (e) { warn('stopHydrationGuard:', e.message); }
  try { stopRouteWatcher();    } catch (e) { warn('stopRouteWatcher:',   e.message); }
  try { stopOsThemeListener(); } catch (e) { warn('stopOsThemeListener:', e.message); }

  // Restore original site state
  try { restoreOriginalState(); } catch (e) { warn('restoreOriginalState:', e.message); }

  // Remove DOM marker
  try {
    document.documentElement.removeAttribute(MARKER_ATTR);
  } catch (e) {
    warn('failed to remove marker:', e.message);
  }

  log('disabled — original state restored');
}

/* ═══════════════════════════════════════════════════════════════════════════
   BOOTSTRAP  (runs at document_start)
   ═══════════════════════════════════════════════════════════════════════════ */
chrome.storage.sync.get({ enabled: true }, ({ enabled: isEnabled }) => {
  log('bootstrap — enabled:', isEnabled, '| readyState:', document.readyState);
  if (isEnabled) enable();
});

/* ─── Message listener ───────────────────────────────────────────────────── */
// Registered exactly once per content script instance (per page load).
// Content scripts are isolated per page — no cross-page duplication possible.
chrome.runtime.onMessage.addListener((msg) => {
  log('message received:', msg.type);
  if (msg.type === 'WTR_ENABLE')  enable();
  if (msg.type === 'WTR_DISABLE') disable();
});
