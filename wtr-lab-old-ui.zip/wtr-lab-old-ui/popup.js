const toggle = document.getElementById('toggle');
const status = document.getElementById('status');

// Load current state
chrome.storage.sync.get({ enabled: true }, ({ enabled }) => {
  toggle.checked = enabled;
  setStatus(enabled);
});

// Toggle changed — send to background, which handles all tabs
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  setStatus(enabled);
  chrome.runtime.sendMessage({ type: 'WTR_TOGGLE', enabled });
});

function setStatus(on) {
  status.textContent = on ? '✓ Old UI active' : '✗ Disabled — showing new UI';
  status.className   = on ? 'status on' : 'status';
}
